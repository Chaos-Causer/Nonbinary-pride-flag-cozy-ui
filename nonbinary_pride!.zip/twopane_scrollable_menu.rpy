################################################################################
#
# Copyright (c) 2020-2021 Dominus Iniquitatis <zerosaiko@gmail.com>
# Copyright (c) 2026 Friends of Monika
#
# See LICENSE file for the licensing information
#
################################################################################
init 999 python:
    # MASFIX: replace basic search bar Solid() by an actual image
    # NOTE: broken on RenPy 7 for some reason;
    if renpy.version(tuple=True)[0] in [6, 8]:
        screens = renpy.display.screen.screens
        screens[("twopane_scrollable_menu", None)].ast.children[3].keyword[4] = (
            "background", "Frame('mod_assets/frames/search_bar.png', Borders(5, 5, 5, 5))"
        )
