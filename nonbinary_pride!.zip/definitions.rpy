################################################################################
#
# Copyright (c) 2020-2021 Dominus Iniquitatis <zerosaiko@gmail.com>
# Copyright (c) 2026 Friends of Monika
#
# See LICENSE file for the licensing information
#
################################################################################
define cozy_ui.common.font_regular     = cozy_ui.expand_path("%SUBMOD_DIR%/themes/active/fonts/ari-w9500.ttf")
define cozy_ui.common.font_italic      = cozy_ui.expand_path("%SUBMOD_DIR%/themes/active/fonts/ari-w9500.ttf")
define cozy_ui.common.font_bold        = cozy_ui.expand_path("%SUBMOD_DIR%/themes/active/fonts/ari-w9500.ttf")
define cozy_ui.common.font_bold_italic = cozy_ui.expand_path("%SUBMOD_DIR%/themes/active/fonts/ari-w9500.ttf")
define cozy_ui.common.font             = FontGroup().add(
    cozy_ui.common.font_regular                 , 0x0020, 0x00ff).add( # Main
    "mod_assets/font/SourceHanSansK-Regular.otf" , 0xac00, 0xd7a3).add( # Korean
    "mod_assets/font/SourceHanSansSC-Regular.otf", 0x4e00, 0x9faf).add( # Simplified chinese
    "mod_assets/font/mplus-2p-regular.ttf"       , 0x3000, 0x4dff).add( # Japanese and others
    "gui/font/Aller_Rg.ttf"                      , 0x0000, 0xffff)      # Fallback
define cozy_ui.common.font_kerning     = 0
define cozy_ui.common.font_size        = 24

define cozy_ui.menu_font         = cozy_ui.expand_path("%SUBMOD_DIR%/themes/active/fonts/ari-w9500-bold.ttf")
define cozy_ui.menu_font_kerning = 0.0

define cozy_ui.menu_title.font_size      = 38
define cozy_ui.menu_title.light.color    = "#ffffff"
define cozy_ui.menu_title.light.outlines = [(6, "#9c59d1", 0, 0), (3, "#9c59d1", 2, 2)]
define cozy_ui.menu_title.dark.color     = "#ffffff"
define cozy_ui.menu_title.dark.outlines  = [(6, "#cac307", 0, 0), (3, "#cac307", 2, 2)]

define cozy_ui.menu_label.font_size      = 24
define cozy_ui.menu_label.light.color    = "#ffffff"
define cozy_ui.menu_label.light.outlines = [(3, "#9c59d1", 0, 0), (1, "#9c59d1", 1, 1)]
define cozy_ui.menu_label.dark.color     = "#ffffff"
define cozy_ui.menu_label.dark.outlines  = [(3, "#cac307", 0, 0), (1, "#cac307", 1, 1)]

define cozy_ui.menu_text.font_size      = 16
define cozy_ui.menu_text.light.color    = "#a2a2a2"
define cozy_ui.menu_text.light.outlines = []
define cozy_ui.menu_text.dark.color     = "#ffffff"
define cozy_ui.menu_text.dark.outlines  = []

define cozy_ui.menu_button_text.font_size                  = 24
define cozy_ui.menu_button_text.light.color                = "#ffffff"
define cozy_ui.menu_button_text.light.idle_outlines        = [(4, "#9c59d1", 0, 0), (2, "#9c59d1", 2, 2)]
define cozy_ui.menu_button_text.light.hover_outlines       = [(4, "#fcf434", 0, 0), (2, "#fcf434", 2, 2)]
define cozy_ui.menu_button_text.light.insensitive_outlines = [(4, "#d7d11c", 0, 0), (2, "#d7d11c", 2, 2)]
define cozy_ui.menu_button_text.dark.color                 = "#ffffff"
define cozy_ui.menu_button_text.dark.idle_outlines         = [(4, "#cac307", 0, 0), (2, "#cac307", 2, 2)]
define cozy_ui.menu_button_text.dark.hover_outlines        = [(4, "#cf99f9", 0, 0), (2, "#cf99f9", 2, 2)]
define cozy_ui.menu_button_text.dark.insensitive_outlines  = [(4, "#9c59d1", 0, 0), (2, "#9c59d1", 2, 2)]

# The song list can carry arbitrary Unicode (custom BGM titles), so the chosen
# font only owns the Latin range; CJK and the rest fall back the same way
# cozy_ui.common.font does, with mplus-2p as the wide-glyph fallback.
define cozy_ui.music_menu_button_text.font                       = FontGroup().add(
    cozy_ui.expand_path("%SUBMOD_DIR%/themes/active/fonts/deltarune.ttf")      , 0x0020, 0x00ff).add( # Chosen font (Latin)
    "mod_assets/font/SourceHanSansK-Regular.otf" , 0xac00, 0xd7a3).add( # Korean
    "mod_assets/font/SourceHanSansSC-Regular.otf", 0x4e00, 0x9faf).add( # Simplified chinese
    "mod_assets/font/mplus-2p-regular.ttf"       , 0x3000, 0x4dff).add( # Japanese and others
    "gui/font/Aller_Rg.ttf"                      , 0x0000, 0xffff)      # Fallback
define cozy_ui.music_menu_button_text.font_kerning               = 0.0
define cozy_ui.music_menu_button_text.font_size                  = 24

# The calendar's day/month names can be localized, so the chosen font only owns
# the Latin range; CJK and the rest fall back like cozy_ui.common.font. Applied
# in calendar.rpy, which swaps gui.default_font to this while MASCalendar builds
# its title, month/year, day-name and day-number Text displayables.
define cozy_ui.calendar.font                                     = FontGroup().add(
    cozy_ui.expand_path("%SUBMOD_DIR%/themes/active/fonts/ari-w9500.ttf")   , 0x0020, 0x00ff).add( # Chosen font (Latin)
    "mod_assets/font/SourceHanSansK-Regular.otf" , 0xac00, 0xd7a3).add( # Korean
    "mod_assets/font/SourceHanSansSC-Regular.otf", 0x4e00, 0x9faf).add( # Simplified chinese
    "mod_assets/font/mplus-2p-regular.ttf"       , 0x3000, 0x4dff).add( # Japanese and others
    "gui/font/Aller_Rg.ttf"                      , 0x0000, 0xffff)      # Fallback
# The calendar date/day-name/month-year text color (MASCalendar.DAY_NUMBER_COLOR),
# applied in calendar.rpy. MAS draws it black; a theme may recolor it.
define cozy_ui.calendar.text_color                              = "#ffffff"
define cozy_ui.music_menu_button_text.light.color                = "#ffffff"
define cozy_ui.music_menu_button_text.light.idle_outlines        = [(3, "#9c59d1", 0, 0), (1, "#9c59d1", 1, 1)]
define cozy_ui.music_menu_button_text.light.hover_outlines       = [(3, "#fcf434", 0, 0), (1, "#fcf434", 1, 1)]
define cozy_ui.music_menu_button_text.light.insensitive_outlines = [(3, "#d7d11c", 0, 0), (1, "#d7d11c", 1, 1)]
define cozy_ui.music_menu_button_text.dark.color                 = "#ffffff"
define cozy_ui.music_menu_button_text.dark.idle_outlines         = [(3, "#cac307", 0, 0), (1, "#cac307", 1, 1)]
define cozy_ui.music_menu_button_text.dark.hover_outlines        = [(3, "#cf99f9", 0, 0), (1, "#cf99f9", 1, 1)]
define cozy_ui.music_menu_button_text.dark.insensitive_outlines  = [(3, "#9c59d1", 0, 0), (1, "#9c59d1", 1, 1)]

define cozy_ui.confirm_prompt_text.light.color    = "#000000"
define cozy_ui.confirm_prompt_text.light.outlines = []
define cozy_ui.confirm_prompt_text.dark.color     = "#9059be"
define cozy_ui.confirm_prompt_text.dark.outlines  = []

define cozy_ui.dialogue_text.vertical_offset = -3
define cozy_ui.dialogue_text.line_spacing    = -1
define cozy_ui.dialogue_text.color           = "#ffffff"
define cozy_ui.dialogue_text.outlines        = [(2, "#1f1f1f", 0, 0)]

define cozy_ui.history_name.color    = "#ffffff"
define cozy_ui.history_name.outlines = [(2, "#1f1f1f", 0, 0)]

define cozy_ui.history_text.color    = "#ffffff"
define cozy_ui.history_text.outlines = [(2, "#1f1f1f", 0, 0)]

define cozy_ui.quick_button_text.font_size               = 14
define cozy_ui.quick_button_text.light.idle_color        = "#ffffff"
define cozy_ui.quick_button_text.light.hover_color       = "#9c59d1"
define cozy_ui.quick_button_text.light.selected_color    = "#ffffff"
define cozy_ui.quick_button_text.light.insensitive_color = "#2c2c2c"
define cozy_ui.quick_button_text.light.outlines          = []
define cozy_ui.quick_button_text.dark.idle_color         = "#ffffff"
define cozy_ui.quick_button_text.dark.hover_color        = "#9c59d1"
define cozy_ui.quick_button_text.dark.selected_color     = "#ffffff"
define cozy_ui.quick_button_text.dark.insensitive_color  = "#2c2c2c"
define cozy_ui.quick_button_text.dark.outlines           = []

define cozy_ui.button.height_adjustment = -4

define cozy_ui.button_text.vertical_offset         = 1
define cozy_ui.button_text.light.idle_color        = "#fcf434"
define cozy_ui.button_text.light.hover_color       = "#ffffff"
define cozy_ui.button_text.light.selected_color    = "#ffffff"
define cozy_ui.button_text.light.insensitive_color = "#ffffff7f"
define cozy_ui.button_text.light.outlines          = []
define cozy_ui.button_text.dark.idle_color         = "#ffffff"
define cozy_ui.button_text.dark.hover_color        = "#ffffff"
define cozy_ui.button_text.dark.selected_color     = "#ffffff"
define cozy_ui.button_text.dark.insensitive_color  = "#ffffff7f"
define cozy_ui.button_text.dark.outlines           = []

# The option (settings check/radio) labels can be localized, so the chosen font
# only owns the Latin range; CJK and the rest fall back like cozy_ui.common.font.
define cozy_ui.option_button_text.font                    = FontGroup().add(
    cozy_ui.expand_path("%SUBMOD_DIR%/themes/active/fonts/ari-w9500-condensed.ttf")     , 0x0020, 0x00ff).add( # Chosen font (Latin)
    "mod_assets/font/SourceHanSansK-Regular.otf" , 0xac00, 0xd7a3).add( # Korean
    "mod_assets/font/SourceHanSansSC-Regular.otf", 0x4e00, 0x9faf).add( # Simplified chinese
    "mod_assets/font/mplus-2p-regular.ttf"       , 0x3000, 0x4dff).add( # Japanese and others
    "gui/font/Aller_Rg.ttf"                      , 0x0000, 0xffff)      # Fallback
define cozy_ui.option_button_text.font_kerning            = 0.0
define cozy_ui.option_button_text.font_size               = 24
define cozy_ui.option_button_text.light.idle_color        = "#ffffff"
define cozy_ui.option_button_text.light.hover_color       = "#fffffb"
define cozy_ui.option_button_text.light.selected_color    = "#faf24c"
define cozy_ui.option_button_text.light.insensitive_color = "#ffffff7f"
define cozy_ui.option_button_text.dark.idle_color         = "#e7e7e7"
define cozy_ui.option_button_text.dark.hover_color        = "#ffffff"
define cozy_ui.option_button_text.dark.selected_color     = "#ffffff"
define cozy_ui.option_button_text.dark.insensitive_color  = "#e7e7e77f"

define cozy_ui.fancy_check_button_text.light.idle_color     = "#757575"
define cozy_ui.fancy_check_button_text.light.hover_color    = "#000000"
define cozy_ui.fancy_check_button_text.light.selected_color = "#000000"
define cozy_ui.fancy_check_button_text.dark.idle_color      = "#757575"
define cozy_ui.fancy_check_button_text.dark.hover_color     = "#000000"
define cozy_ui.fancy_check_button_text.dark.selected_color  = "#000000"

define cozy_ui.scrollable_menu_button_spacing = 6
define cozy_ui.choice_button_spacing          = 12
define cozy_ui.talk_button_spacing            = 16
define cozy_ui.hotkey_button_spacing          = 5

define cozy_ui.input_caret_color = "#9c59d1"
